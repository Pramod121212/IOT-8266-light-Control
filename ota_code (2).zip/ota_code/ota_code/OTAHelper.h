#ifndef OTA_HELPER_H
#define OTA_HELPER_H

#include <ArduinoOTA.h>
#include <ESP8266WiFi.h>
extern const char* ssid;
extern const char* password;
extern const char* hostname;
extern const char* ota_password;
void setupOTA();
void handleOTA();

#endif
