#ifndef UDP_HELPER_H
#define UDP_HELPER_H

#include <WiFiUdp.h>

void setupUDP(IPAddress targetIP, uint16_t port);
void sendUDPV(int value);
void sendUDPS(char *s);

#endif
