#include "UDPHelper.h"

WiFiUDP udp;
IPAddress targetIP;
uint16_t udpPort;

void setupUDP(IPAddress ip, uint16_t port) {
  targetIP = ip;
  udpPort = port;
}

void sendUDPV(int value) {
  String message = String(value);
  udp.beginPacket(targetIP, udpPort);
  udp.print(message);
  udp.endPacket();
}
void sendUDPS(char *s) {
  String message = s;
  udp.beginPacket(targetIP, udpPort);
  udp.print(message);
  udp.endPacket();
}
